import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class PaidHistoryScreen extends StatefulWidget {
  const PaidHistoryScreen({Key? key}) : super(key: key);

  @override
  State<PaidHistoryScreen> createState() => _PaidHistoryScreenState();
}

class _PaidHistoryScreenState extends State<PaidHistoryScreen> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  List<dynamic> _history = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetchHistory();
  }

  Future<void> _fetchHistory() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final response = await http.get(
        Uri.parse('https://buildwish.nexltech.com/public/api/payment-history'),
        headers: {
          'Accept': 'application/json',
          'Authorization':
              'Bearer 2|2Fc6Iwa8PqLaupdFE06XuORuF4DLGGn0Qq7c2yVs6c30e9be',
        },
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          _history = data['history'] ?? data;
          _isLoading = false;
        });
      } else {
        setState(() {
          _error = 'Failed to load history';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = 'Error: $e';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: const Color(0xFF101010),
        appBar: AppBar(
          backgroundColor: const Color(0xFF101010),
          automaticallyImplyLeading: false,
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30,
            ),
            onPressed: () async {
              Navigator.of(context).pop();
            },
          ),
          title: const Align(
            alignment: AlignmentDirectional(-1, 0),
            child: Text(
              'History',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                letterSpacing: 0.0,
                fontWeight: FontWeight.normal,
              ),
            ),
          ),
          centerTitle: false,
          elevation: 2,
        ),
        body: SafeArea(
          top: true,
          child: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _error != null
                  ? Center(
                      child: Text(_error!,
                          style: const TextStyle(color: Colors.red)))
                  : _history.isEmpty
                      ? const Center(
                          child: Text('No payment history found',
                              style: TextStyle(color: Colors.white)))
                      : ListView.builder(
                          itemCount: _history.length,
                          itemBuilder: (context, index) {
                            final item = _history[index];
                            return Card(
                              color: const Color(0xFF0F4864),
                              margin: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 8),
                              child: ListTile(
                                leading: const Icon(Icons.payment,
                                    color: Colors.white),
                                title: Text(
                                  'Amount:  24${item['amount'] ?? ''}',
                                  style: const TextStyle(color: Colors.white),
                                ),
                                subtitle: Text(
                                  'Date:  24${item['date'] ?? item['created_at'] ?? ''}',
                                  style: const TextStyle(color: Colors.white70),
                                ),
                                trailing: Text(
                                  item['status'] ?? 'Paid',
                                  style: const TextStyle(
                                      color: Colors.greenAccent),
                                ),
                              ),
                            );
                          },
                        ),
        ),
      ),
    );
  }
}
