import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:paraphrase/app_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class SubscriptionPlanScreen extends StatefulWidget {
  const SubscriptionPlanScreen({Key? key}) : super(key: key);

  @override
  State<SubscriptionPlanScreen> createState() => _SubscriptionPlanScreenState();
}

class _SubscriptionPlanScreenState extends State<SubscriptionPlanScreen> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  String? _selectedPlan;
  bool _isLoading = false;
  late SharedPreferences _prefs;
  static const String _secretKey =
      'sk_test_51RawSy4RsMMWl5TI7tqelSNJDkLXiuLbWcYLHxKZ8BkNf23LFIADaLuLpJZtnCkzV0GHkn5haB18hWpj4Ch6BrzK00U3fyznDU';
  static const String _baseUrl = 'https://api.stripe.com/v1';

  @override
  void initState() {
    super.initState();
    _initializeServices();
  }

  Future<void> _initializeServices() async {
    _prefs = await SharedPreferences.getInstance();
  }

  Future<String?> _createPaymentIntent(int amount, String currency) async {
    final url = Uri.parse('https://api.stripe.com/v1/payment_intents');
    final response = await http.post(
      url,
      headers: {
        'Authorization': 'Bearer $_secretKey',
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: {
        'amount': amount.toString(),
        'currency': currency,
        'payment_method_types[]': 'card',
      },
    );
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      return data['client_secret'];
    } else {
      print('Failed to create PaymentIntent: \\n${response.body}');
      return null;
    }
  }

  Future<void> _handleSubscription() async {
    if (_selectedPlan == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(AppLocalizations.of(context)!
                    .translate("Please select a plan") ??
                "Please select a plan")),
      );
      return;
    }
    setState(() => _isLoading = true);
    try {
      // Set amount based on plan
      int amount = _selectedPlan == 'monthly' ? 1900 : 2900; // in cents
      String currency = 'usd';
      final clientSecret = await _createPaymentIntent(amount, currency);
      if (clientSecret == null) {
        throw Exception('Failed to create payment intent');
      }
      await Stripe.instance.initPaymentSheet(
        paymentSheetParameters: SetupPaymentSheetParameters(
          paymentIntentClientSecret: clientSecret,
          merchantDisplayName: 'Paraphrase',
        ),
      );
      await Stripe.instance.presentPaymentSheet();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(AppLocalizations.of(context)!
                    .translate('Payment successful!') ??
                'Payment successful!')),
      );
      Navigator.pop(context, true);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(
                '${AppLocalizations.of(context)!.translate('Payment failed: ') ?? 'Payment failed: '}$e')),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _showManageSubscriptionDialog() async {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: const Color(0xFF1E1E1E),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: SizedBox(
            width: 350,
            child: Center(
              child: Padding(
                padding: EdgeInsets.all(24.0),
                child: Text(
                  AppLocalizations.of(context)!.translate(
                          'Manage your subscription here. (Feature coming soon)') ??
                      'Manage your subscription here. (Feature coming soon)',
                  style: TextStyle(fontSize: 18, color: Colors.white),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: const Color(0xFF1E1E1E),
        appBar: AppBar(
          backgroundColor: const Color(0xFF1E1E1E),
          automaticallyImplyLeading: false,
          leading: IconButton(
            icon: const Icon(
              Icons.chevron_left_rounded,
              color: Colors.white,
              size: 30,
            ),
            onPressed: () => Navigator.of(context).pop(),
          ),
          title: Text(
            AppLocalizations.of(context)!.translate('Subscription Plan') ??
                'Subscription Plan',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
            ),
          ),
          actions: const [
            Padding(
              padding: EdgeInsets.only(right: 20),
              child: FaIcon(
                FontAwesomeIcons.crown,
                color: Color(0xFFFFC100),
                size: 24,
              ),
            ),
          ],
          centerTitle: false,
          elevation: 2,
        ),
        body: SafeArea(
          top: true,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                // Features Block
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: const Color(0xFF2A2A2A),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    children: [
                      Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFAD00),
                          borderRadius: BorderRadius.circular(25),
                        ),
                        child: const Icon(
                          FontAwesomeIcons.faceFrown,
                          color: Colors.white,
                          size: 24,
                        ),
                      ),
                      const SizedBox(height: 15),
                      Text(
                        AppLocalizations.of(context)!.translate(
                                'Supercharge your ✨Reading & Writing') ??
                            'Supercharge your ✨Reading & Writing',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 10),
                      FeatureText(AppLocalizations.of(context)!.translate(
                              '✓ Unlimited generation of summaries') ??
                          '✓ Unlimited generation of summaries'),
                      FeatureText(AppLocalizations.of(context)!.translate(
                              '✓ Unlimited generation of paraphrases') ??
                          '✓ Unlimited generation of paraphrases'),
                      FeatureText(AppLocalizations.of(context)!
                              .translate('✓ Unlimited files / PDFs / URLs') ??
                          '✓ Unlimited files / PDFs / URLs'),
                      FeatureText(AppLocalizations.of(context)!
                              .translate('✓ Unlimited Length') ??
                          '✓ Unlimited Length'),
                      FeatureText(AppLocalizations.of(context)!
                              .translate('✓ Any tone') ??
                          '✓ Any tone'),
                      FeatureText(AppLocalizations.of(context)!
                              .translate('✓ 10+ languages supported') ??
                          '✓ 10+ languages supported'),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // Basic Tag
                _buildTag("Basic", bgColor: const Color(0xFF212121)),

                const SizedBox(height: 10),

                // Monthly Plan
                _buildPlanTile(
                  title: "\$19",
                  subtitle: "/Month",
                  value: 'monthly',
                ),

                const SizedBox(height: 10),

                // Most Popular Tag
                _buildTag("Most Popular",
                    gradient: const LinearGradient(
                      colors: [Color(0xFF23AEF0), Color(0xFF013D5A)],
                    )),

                const SizedBox(height: 10),

                // Yearly Plan
                _buildPlanTile(
                  title: "\$29",
                  subtitle: "/Year",
                  value: 'yearly',
                  gradient: const LinearGradient(
                    colors: [Color(0xFF23AEF0), Color(0xFF013D5A)],
                  ),
                ),

                const SizedBox(height: 30),

                // Claim Button
                GestureDetector(
                  onTap: _isLoading ? null : _handleSubscription,
                  child: Container(
                    width: double.infinity,
                    height: 50,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF23AEF0), Color(0xFF0F4864)],
                      ),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    alignment: Alignment.center,
                    child: _isLoading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : const Text(
                            'Claim Subscription',
                            style: TextStyle(
                              color: Color(0xFFF7F9F6),
                              fontSize: 18,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                  ),
                ),
                const SizedBox(height: 16),
                // Manage My Subscription Button
                GestureDetector(
                  onTap: _isLoading ? null : _showManageSubscriptionDialog,
                  child: Container(
                    width: double.infinity,
                    height: 50,
                    decoration: BoxDecoration(
                      color: const Color(0xFF0F4864),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    alignment: Alignment.center,
                    child: const Text(
                      'Manage My Subscription',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPlanTile({
    required String title,
    required String subtitle,
    required String value,
    Gradient? gradient,
  }) {
    return Container(
      width: double.infinity,
      height: 87,
      decoration: BoxDecoration(
        gradient: gradient ??
            const LinearGradient(
              colors: [Color(0xFF212121), Color(0xFF504E4E)],
            ),
        borderRadius: BorderRadius.circular(20),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Color(0xFFF7F9F6),
              fontSize: 32,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(width: 6),
          Padding(
            padding: const EdgeInsets.only(top: 15),
            child: Text(
              subtitle,
              style: const TextStyle(
                color: Color(0xFF949494),
                fontSize: 16,
              ),
            ),
          ),
          const Spacer(),
          Radio<String>(
            value: value,
            groupValue: _selectedPlan,
            onChanged: (val) {
              setState(() {
                _selectedPlan = val;
              });
            },
            activeColor: Colors.white,
            fillColor: WidgetStateProperty.all(Colors.white),
          ),
        ],
      ),
    );
  }

  Widget _buildTag(String label, {Color? bgColor, Gradient? gradient}) {
    return Container(
      width: 135,
      height: 29,
      decoration: BoxDecoration(
        color: bgColor,
        gradient: gradient,
        borderRadius: BorderRadius.circular(24),
      ),
      alignment: Alignment.center,
      child: Text(
        label,
        style: const TextStyle(
          color: Color(0xFFF7F9F6),
          fontSize: 16,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}

class FeatureText extends StatelessWidget {
  final String text;

  const FeatureText(this.text, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 16,
        ),
      ),
    );
  }
}
