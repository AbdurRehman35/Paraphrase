import 'package:flutter/material.dart';
import 'services/auth_service.dart';
import 'HomeScreen.dart';
import 'package:provider/provider.dart';
import 'app_localizations.dart';
import 'locale_provider.dart';

class SplashScreens extends StatefulWidget {
  @override
  _SplashScreensState createState() => _SplashScreensState();
}

class _SplashScreensState extends State<SplashScreens> {
  final PageController _controller = PageController();
  int _currentPage = 0;
  final AuthService _authService = AuthService();

  final List<Map<String, String>> splashData = [
    {
      "titleKey": "AI-Powered Reading & Writing Assistant",
      "descKey":
          "Get accurate and natural paraphrasing, summarization, and grammar correction in seconds.",
      "image": "assets/images/kids.png"
    },
    {
      "titleKey": "Works with Any Format",
      "descKey":
          "Upload PDFs, paste text, or provide a URL—our AI seamlessly enhances your content!",
      "image": "assets/images/bussiness.png"
    },
    {
      "titleKey": "Enhance Your Writing Instantly",
      "descKey":
          "Save time and boost productivity with AI-driven rewriting and summarization.",
      "image": "assets/images/ai.png"
    },
  ];

  void _showConnectDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
              AppLocalizations.of(context)!.translate('Continue with') ??
                  'Connect with'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ElevatedButton.icon(
                icon: Icon(Icons.g_mobiledata),
                label: Text(AppLocalizations.of(context)!
                        .translate('Continue with Google') ??
                    'Continue with Google'),
                onPressed: () async {
                  try {
                    print('Starting Google login...');
                    final userData = await _authService.signInWithGoogle();
                    if (userData != null) {
                      Navigator.pop(context);
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => HomeScreen()),
                      );
                    } else {
                      print('Google login failed: No user data returned');
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                            content: Text(AppLocalizations.of(context)!.translate(
                                    'Google login failed. Please try again.') ??
                                'Google login failed. Please try again.')),
                      );
                    }
                  } catch (e) {
                    print('Google login error: $e');
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Error during Google login: $e')),
                    );
                  }
                },
              ),
              SizedBox(height: 16),
              // ElevatedButton.icon(
              //   icon: Icon(Icons.facebook, color: Colors.white),
              //   label: Text("Continue with Facebook"),
              //   style: ElevatedButton.styleFrom(
              //       backgroundColor: Color(0xFF1877F3)),
              //   onPressed: () async {
              //     try {
              //       print('Starting Facebook login...');
              //       final userData = await _authService.signInWithFacebook();
              //       if (userData != null) {
              //         Navigator.pop(context);
              //         Navigator.pushReplacement(
              //           context,
              //           MaterialPageRoute(builder: (context) => HomeScreen()),
              //         );
              //       } else {
              //         print('Facebook login failed: No user data returned');
              //         ScaffoldMessenger.of(context).showSnackBar(
              //           SnackBar(
              //               content: Text(
              //                   'Facebook login failed. Please try again.')),
              //         );
              //       }
              //     } catch (e) {
              //       print('Facebook login error: $e');
              //       ScaffoldMessenger.of(context).showSnackBar(
              //         SnackBar(
              //             content: Text('Error during Facebook login: $e')),
              //       );
              //     }
              //   },
              // ),
              // SizedBox(height: 16),
              // ElevatedButton.icon(
              //   icon: Icon(Icons.apple),
              //   label: Text("Continue with Apple"),
              //   onPressed: () async {
              //     try {
              //       //   print('Starting Apple login...');
              //       final userData = await _authService.signInWithApple();
              //       if (userData != null) {
              //         Navigator.pop(context);
              //         Navigator.pushReplacement(
              //           context,
              //           MaterialPageRoute(builder: (context) => HomeScreen()),
              //         );
              //       } else {
              //         print('Apple login failed: No user data returned');
              //         ScaffoldMessenger.of(context).showSnackBar(
              //           SnackBar(
              //               content:
              //                   Text('Apple login failed. Please try again.')),
              //         );
              //       }
              //     } catch (e) {
              //       print('Apple login error: $e');
              //       ScaffoldMessenger.of(context).showSnackBar(
              //         SnackBar(content: Text('Error during Apple login: $e')),
              //       );
              //     }
              //   },
              //   style: ElevatedButton.styleFrom(backgroundColor: Colors.black),
              // ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildPageContent(Map<String, String> data) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Image.asset(data["image"]!, height: 250),
        ),
        SizedBox(height: 20),
        Text(
          AppLocalizations.of(context)!.translate(data['titleKey']!) ??
              data['titleKey']!,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Color(0xFFE1E1E1),
          ),
        ),
        SizedBox(height: 12),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Text(
            AppLocalizations.of(context)!.translate(data['descKey']!) ??
                data['descKey']!,
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white70),
          ),
        ),
        SizedBox(height: 30),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: _showConnectDialog,
              child: Text(
                  AppLocalizations.of(context)!.translate('Get Started') ??
                      'Get Started'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.cyan,
                padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12),
              ),
            ),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          PopupMenuButton<String>(
            onSelected: (String languageCode) {
              Provider.of<LocaleProvider>(context, listen: false)
                  .setLocale(Locale(languageCode));
            },
            icon: Icon(Icons.language, color: Colors.white),
            itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
              const PopupMenuItem<String>(
                value: 'en',
                child: Text('English'),
              ),
              const PopupMenuItem<String>(
                value: 'es',
                child: Text('Español'),
              ),
              const PopupMenuItem<String>(
                value: 'fr',
                child: Text('Français'),
              ),
              const PopupMenuItem<String>(
                value: 'ar',
                child: Text('العربية'),
              ),
            ],
          ),
        ],
      ),
      body: PageView.builder(
        controller: _controller,
        onPageChanged: (index) => setState(() => _currentPage = index),
        itemCount: splashData.length,
        itemBuilder: (context, index) {
          return _buildPageContent(splashData[index]);
        },
      ),
      bottomSheet: Container(
        color: Colors.black,
        padding: EdgeInsets.only(bottom: 20),
        height: 60,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(
            splashData.length,
            (index) => AnimatedContainer(
              duration: Duration(milliseconds: 300),
              margin: EdgeInsets.symmetric(horizontal: 4),
              height: 8,
              width: _currentPage == index ? 20 : 8,
              decoration: BoxDecoration(
                color: _currentPage == index ? Colors.cyan : Colors.grey,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
