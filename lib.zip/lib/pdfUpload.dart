import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:io';

import 'package:paraphrase/app_localizations.dart';
import 'package:paraphrase/pdfUpload3.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class PdfUploadScreen extends StatefulWidget {
  const PdfUploadScreen({super.key});

  @override
  State<PdfUploadScreen> createState() => _PdfUploadScreenState();
}

class _PdfUploadScreenState extends State<PdfUploadScreen> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  File? selectedPdfFile;
  String? fileName;
  String? fileSize;

  Future<void> _pickPdfFile() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf'],
        allowMultiple: false,
      );

      if (result != null && result.files.single.path != null) {
        setState(() {
          selectedPdfFile = File(result.files.single.path!);
          fileName = result.files.single.name;

          // Calculate file size
          int fileSizeInBytes = selectedPdfFile!.lengthSync();
          if (fileSizeInBytes < 1024) {
            fileSize = '$fileSizeInBytes B';
          } else if (fileSizeInBytes < 1024 * 1024) {
            fileSize = '${(fileSizeInBytes / 1024).toStringAsFixed(1)} KB';
          } else {
            fileSize =
                '${(fileSizeInBytes / (1024 * 1024)).toStringAsFixed(1)} MB';
          }
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(AppLocalizations.of(context)!
                    .translate('PDF file selected successfully!') ??
                'PDF file selected successfully!'),
            backgroundColor: Color(0xFF5FF2A1),
            duration: Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
              '${AppLocalizations.of(context)!.translate('Error picking file: ') ?? 'Error picking file: '}$e'),
          backgroundColor: Colors.red,
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  void _removePdfFile() {
    setState(() {
      selectedPdfFile = null;
      fileName = null;
      fileSize = null;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
            AppLocalizations.of(context)!.translate('PDF file removed') ??
                'PDF file removed'),
        backgroundColor: Color(0xFF4083D1),
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: const Color(0xFF101010),
        appBar: AppBar(
          backgroundColor: const Color(0xFF101010),
          automaticallyImplyLeading: false,
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: const Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
              size: 24,
            ),
            padding: const EdgeInsets.only(left: 8),
          ),
          title: Text(
            AppLocalizations.of(context)!.translate('PDF Upload') ??
                'PDF Upload',
            style: TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.w600,
            ),
          ),
          actions: [
            const Icon(
              Icons.av_timer_rounded,
              color: Colors.white,
              size: 24,
            ),
            const SizedBox(width: 16),
            GestureDetector(
              onTap: () {
                Navigator.pushNamed(context, '/subscription');
              },
              child: const FaIcon(
                FontAwesomeIcons.crown,
                color: Color(0xFFFFCC00),
                size: 24,
              ),
            ),
            const SizedBox(width: 16),
          ],
          centerTitle: false,
        ),
        body: SafeArea(
          top: true,
          child: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      // Blue Banner
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 30, 16, 20),
                        child: Container(
                          width: double.infinity,
                          height: 69,
                          decoration: BoxDecoration(
                            color: const Color(0xFF1D252B),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: Text(
                                    selectedPdfFile == null
                                        ? AppLocalizations.of(context)!.translate(
                                                'Please Share with us the PDF file') ??
                                            'Please Share with us the PDF file'
                                        : AppLocalizations.of(context)!.translate(
                                                'PDF file selected successfully') ??
                                            'PDF file selected successfully',
                                    style: TextStyle(
                                      color: selectedPdfFile == null
                                          ? const Color(0xFF4083D1)
                                          : const Color(0xFF5FF2A1),
                                      fontSize: 17,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                                IconButton(
                                  onPressed: selectedPdfFile == null
                                      ? _pickPdfFile
                                      : _removePdfFile,
                                  icon: Container(
                                    width: 40,
                                    height: 40,
                                    decoration: BoxDecoration(
                                      color: const Color(0xFF273E55),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Icon(
                                      selectedPdfFile == null
                                          ? Icons.add_circle
                                          : Icons.remove_circle,
                                      color: selectedPdfFile == null
                                          ? const Color(0xFF4083D1)
                                          : Colors.red,
                                      size: 24,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),

                      // Upload Area / File Display - Dynamic height based on content
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 300),
                          width: double.infinity,
                          // Dynamic height based on selected file
                          height: selectedPdfFile == null ? 280 : 200,
                          decoration: BoxDecoration(
                            color: const Color(0xFF1D252B),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: selectedPdfFile == null
                                  ? Colors.white
                                  : const Color(0xFF5FF2A1),
                              width: selectedPdfFile == null ? 1 : 2,
                            ),
                          ),
                          child: selectedPdfFile == null
                              ? _buildUploadArea()
                              : _buildFileDisplay(),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // Next Button
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 40),
                child: Align(
                  alignment: Alignment.centerRight,
                  child: ElevatedButton.icon(
                    onPressed: selectedPdfFile != null
                        ? () {
                            // Navigate to next screen with the selected file
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => Pdf3Screen(
                                          title: 'PDF',
                                          api: 'pdf',
                                          file: selectedPdfFile,
                                        )));
                          }
                        : null,
                    icon: const Icon(
                      Icons.arrow_forward_ios_rounded,
                      size: 15,
                      color: Colors.white,
                    ),
                    label: const Text(
                      'Next',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: selectedPdfFile != null
                          ? const Color(0xFF25A6E3)
                          : Colors.grey,
                      minimumSize: const Size(182, 48),
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      elevation: 0,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildUploadArea() {
    return InkWell(
      onTap: _pickPdfFile,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.cloud_upload_outlined,
            color: Color(0xFF4083D1),
            size: 80,
          ),
          const SizedBox(height: 20),
          Text(
            AppLocalizations.of(context)!.translate('Click To Upload PDF') ??
                'Click To Upload PDF',
            style: const TextStyle(
              color: Color(0xFFF1F2F2),
              fontSize: 20,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            AppLocalizations.of(context)!.translate('Supported format: PDF') ??
                'Supported format: PDF',
            style: const TextStyle(
              color: Color(0xFF9CA3AF),
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFileDisplay() {
    return SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.picture_as_pdf,
            color: Color(0xFF5FF2A1),
            size: 60,
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              fileName ?? '',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          if (fileSize != null) ...[
            const SizedBox(height: 8),
            Text(
              '${AppLocalizations.of(context)!.translate('File Size: ') ?? 'File Size: '}$fileSize',
              style: const TextStyle(
                color: Colors.grey,
                fontSize: 14,
              ),
            ),
          ],
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: _pickPdfFile,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF273E55),
              foregroundColor: const Color(0xFF4083D1),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: Text(
                AppLocalizations.of(context)!.translate('Change File') ??
                    'Change File'),
          ),
        ],
      ),
    );
  }
}
