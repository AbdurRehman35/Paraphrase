import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:paraphrase/app_localizations.dart';
import 'package:paraphrase/audioFile2.dart';
import 'package:paraphrase/pdfUpload3.dart';
import 'package:paraphrase/subscription.dart';

class AudioFileScreen extends StatefulWidget {
  const AudioFileScreen({
    Key? key,
  }) : super(key: key);

  @override
  State<AudioFileScreen> createState() => _AudioFileScreenState();
}

class _AudioFileScreenState extends State<AudioFileScreen> {
  File? selectedAudioFile;
  String? fileName;
  bool isLoading = false;
  String? fileSize;

  Future<void> pickAudioFile() async {
    setState(() {
      isLoading = true;
    });

    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.audio,
        // allowedExtensions: ['mp3'], // Only allow mp3 files
      );

      if (result != null) {
        setState(() {
          selectedAudioFile = File(result.files.single.path!);
          fileName = result.files.single.name;
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error picking audio file: $e')),
      );
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor: const Color(0xFF101010),
        appBar: AppBar(
          backgroundColor: const Color(0xFF101010),
          automaticallyImplyLeading: false,
          leading: IconButton(
            icon:
                const Icon(Icons.arrow_back_ios, color: Colors.white, size: 24),
            onPressed: () => Navigator.of(context).pop(),
          ),
          title: Text(
            AppLocalizations.of(context)!.translate('Audio File') ??
                'Audio File',
            style: TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.w600,
            ),
          ),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 30),
              child: Icon(
                Icons.av_timer_rounded,
                color: Colors.white,
                size: 24,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(right: 10),
              child: IconButton(
                icon: FaIcon(
                  FontAwesomeIcons.crown,
                  color: const Color(0xFFFFCC00),
                  size: 24,
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const SubscriptionPlanScreen(),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
        body: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              // Blue banner
              Align(
                alignment: Alignment.topCenter,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(0, 30, 0, 20),
                  child: Container(
                    width: 364,
                    height: 69,
                    decoration: BoxDecoration(
                      color: const Color(0xFF1D252B),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(left: 16),
                          child: Text(
                            AppLocalizations.of(context)!.translate(
                                    'Please share with us the audio file') ??
                                'Please share with us the audio file',
                            style: TextStyle(
                              color: Color(0xFF4083D1),
                              fontSize: 17,
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(right: 10),
                          child: Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: const Color(0xFF273E55),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: IconButton(
                              icon: const Icon(
                                Icons.add_circle,
                                color: Color(0xFF4083D1),
                                size: 24,
                              ),
                              onPressed: () {},
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // Upload area
              Padding(
                padding: const EdgeInsets.only(top: 50),
                child: Container(
                  width: 361,
                  height: 238,
                  decoration: BoxDecoration(
                    color: const Color(0xFF1D252B),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.white),
                  ),
                  child: Center(
                    child: Container(
                      width: 320,
                      height: 200,
                      decoration: BoxDecoration(
                        color: const Color(0xFF1D252B),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: const Color(0xFF4083D1),
                        ),
                      ),
                      child: InkWell(
                        onTap: pickAudioFile,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            if (selectedAudioFile == null) ...[
                              // Audio icon
                              const Icon(
                                Icons.audiotrack_outlined,
                                color: Color(0xFF4083D1),
                                size: 50,
                              ),
                              const SizedBox(height: 20),
                              // Upload text
                              Text(
                                AppLocalizations.of(context)!
                                        .translate('Click To Upload Audio') ??
                                    'Click To Upload Audio',
                                style: TextStyle(
                                  color: Color(0xFFF1F2F2),
                                  fontSize: 20,
                                ),
                              ),
                              const SizedBox(height: 10),
                              // Format text
                              Text(
                                AppLocalizations.of(context)!
                                        .translate('Supported format: MP3') ??
                                    'Supported format: MP3',
                                style: TextStyle(
                                  color: Color(0xFF9CA3AF),
                                  fontSize: 16,
                                ),
                              ),
                            ] else ...[
                              // Show selected file info
                              const Icon(
                                Icons.audiotrack,
                                color: Color(0xFF4083D1),
                                size: 50,
                              ),
                              const SizedBox(height: 20),
                              Text(
                                fileName ??
                                    AppLocalizations.of(context)!
                                        .translate('Audio file selected') ??
                                    'Audio file selected',
                                style: const TextStyle(
                                  color: Color(0xFFF1F2F2),
                                  fontSize: 18,
                                ),
                                textAlign: TextAlign.center,
                              ),
                              const SizedBox(height: 10),
                              ElevatedButton(
                                onPressed: pickAudioFile,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xFF273E55),
                                  foregroundColor: const Color(0xFF4083D1),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                                child: Text(AppLocalizations.of(context)!
                                        .translate('Change File') ??
                                    'Change File'),
                              ),
                            ],
                            if (isLoading)
                              const CircularProgressIndicator(
                                color: Color(0xFF4083D1),
                              ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              // Spacer to push Next button to bottom
              const Spacer(),

              // Next button
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: ElevatedButton(
                  onPressed: selectedAudioFile != null
                      ? () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => Pdf3Screen(
                                title: AppLocalizations.of(context)!
                                        .translate('Audio File') ??
                                    'Audio File',
                                api: 'audio',
                                file: selectedAudioFile,
                              ),
                            ),
                          );
                        }
                      : null, // Button is disabled if no file is selected
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF4083D1),
                    minimumSize: const Size(double.infinity, 50),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    AppLocalizations.of(context)!.translate('Next') ?? 'Next',
                    style: const TextStyle(color: Colors.white, fontSize: 18),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
