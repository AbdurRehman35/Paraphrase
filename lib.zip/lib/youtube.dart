import 'package:flutter/material.dart';
import 'package:paraphrase/website2.dart';
import 'package:paraphrase/youtube2.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class YouTubeScreen extends StatefulWidget {
  const YouTubeScreen({super.key});

  @override
  State<YouTubeScreen> createState() => _YouTubeScreenState();
}

class _YouTubeScreenState extends State<YouTubeScreen> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  final TextEditingController textController = TextEditingController();
  final FocusNode textFieldFocusNode = FocusNode();

  @override
  void dispose() {
    textController.dispose();
    textFieldFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: const Color(0xFF101010),
        appBar: AppBar(
          backgroundColor: const Color(0xFF101010),
          automaticallyImplyLeading: false,
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: const Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
              size: 24,
            ),
            padding: const EdgeInsets.only(left: 8),
          ),
          title: const Text(
            'YouTube',
            style: TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.w600,
            ),
          ),
          actions: [
            const Icon(
              Icons.av_timer_rounded,
              color: Colors.white,
              size: 24,
            ),
            const SizedBox(width: 16),
            const FaIcon(
              FontAwesomeIcons.crown,
              color: Color(0xFFFFCC00),
              size: 24,
            ),
            const SizedBox(width: 16),
          ],
          centerTitle: false,
        ),
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              // Blue Banner
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 30, 16, 20),
                child: Container(
                  width: double.infinity,
                  height: 69,
                  decoration: BoxDecoration(
                    color: const Color(0xFF1D252B),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Enter YouTube URL',
                          style: TextStyle(
                            color: Color(0xFF4A9EFF),
                            fontSize: 17,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        IconButton(
                          onPressed: () {
                            print('Add button pressed');
                          },
                          icon: Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: const Color(0xFF273E55),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Icon(
                              Icons.add_circle,
                              color: Color(0xFF4083D1),
                              size: 24,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // YouTube URL Text Field
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 25, 16, 0),
                child: TextFormField(
                  controller: textController,
                  focusNode: textFieldFocusNode,
                  autofocus: false,
                  obscureText: false,
                  decoration: InputDecoration(
                    isDense: true,
                    labelStyle: const TextStyle(
                      color: Color(0xFFE0DEE2),
                      fontSize: 14,
                    ),
                    hintText: 'Type YouTube Link Here',
                    hintStyle: const TextStyle(
                      color: Color(0xFFE0DEE2),
                      fontSize: 14,
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        color: Colors.white,
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        color: Colors.white,
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    errorBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        color: Colors.red,
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    focusedErrorBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        color: Colors.red,
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    filled: true,
                    fillColor: const Color(0xFF0F4864),
                    prefixIcon: const Icon(
                      Icons.play_circle_outline,
                      color: Color(0xFFE0DEE2),
                      size: 24,
                    ),
                  ),
                  style: const TextStyle(
                    color: Color(0xFFE0DEE2),
                    fontSize: 16,
                  ),
                  cursorColor: Colors.white,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a YouTube URL';
                    }
                    if (!value.contains('youtube.com') &&
                        !value.contains('youtu.be')) {
                      return 'Please enter a valid YouTube URL';
                    }
                    return null;
                  },
                ),
              ),

              const Spacer(),

              // Next Button
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 40),
                child: Align(
                  alignment: Alignment.centerRight,
                  child: ElevatedButton.icon(
                    onPressed: textController.text.trim().isNotEmpty &&
                            _isValidUrl(_formatUrl(textController.text))
                        ? () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => YouTube2Screen(
                                  YoutubeUrl: _formatUrl(textController.text),
                                ),
                              ),
                            );
                          }
                        : null,
                    icon: const Icon(
                      Icons.arrow_forward_ios_rounded,
                      size: 15,
                      color: Colors.white,
                    ),
                    label: const Text(
                      'Next',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF25A6E3),
                      minimumSize: const Size(182, 48),
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      elevation: 0,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

String _formatUrl(String url) {
  return url.trim();
}

bool _isValidUrl(String url) {
  return url.contains('youtube.com') || url.contains('youtu.be');
}
