import 'package:flutter/material.dart';

class ColorConstant {
  static const Color primaryColor = Color(0xFF25A6E3);
}
