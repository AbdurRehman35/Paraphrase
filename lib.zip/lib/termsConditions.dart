import 'package:flutter/material.dart';
import 'package:paraphrase/app_localizations.dart';

class TermsConditionsScreen extends StatefulWidget {
  const TermsConditionsScreen({Key? key}) : super(key: key);

  @override
  State<TermsConditionsScreen> createState() => _TermsConditionsScreenState();
}

class _TermsConditionsScreenState extends State<TermsConditionsScreen> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: const Color(0xFF101010),
        appBar: AppBar(
          backgroundColor: const Color(0xFF101010),
          automaticallyImplyLeading: false,
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30,
            ),
            onPressed: () async {
              Navigator.of(context).pop();
            },
          ),
          title: Align(
            alignment: AlignmentDirectional(-1, 0),
            child: Text(
              AppLocalizations.of(context)!.translate('Terms & Conditions') ??
                  'Terms & Conditions',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                letterSpacing: 0.0,
              ),
            ),
          ),
          centerTitle: false,
          elevation: 2,
        ),
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Terms Title
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(20, 10, 0, 0),
                child: Text(
                  AppLocalizations.of(context)!.translate('Terms:') ?? 'Terms:',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    letterSpacing: 0.0,
                  ),
                ),
              ),

              // Terms Text (Justified + Centered horizontally)
              Center(
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Text(
                    AppLocalizations.of(context)!.translate(
                            'By accessing or using services, you agree to comply with these Terms. You must use the Service only for lawful purposes and in accordance with applicable laws. You are responsible for maintaining the confidentiality of your account information. We reserve the right to suspend or terminate your access if you violate these Terms. All content on the Service is protected by copyright and may not be reproduced without permission. The Service is provided "as is" without warranties of any kind. We are not liable for any damages resulting from your use of the Service. These Terms may be updated periodically, and your continued use of the Service constitutes acceptance of the changes. Disputes will be governed by the laws of.') ??
                        'By accessing or using services, you agree to comply with these Terms. You must use the Service only for lawful purposes and in accordance with applicable laws. You are responsible for maintaining the confidentiality of your account information. We reserve the right to suspend or terminate your access if you violate these Terms. All content on the Service is protected by copyright and may not be reproduced without permission. The Service is provided "as is" without warranties of any kind. We are not liable for any damages resulting from your use of the Service. These Terms may be updated periodically, and your continued use of the Service constitutes acceptance of the changes. Disputes will be governed by the laws of.',
                    textAlign: TextAlign.justify,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      letterSpacing: 0.0,
                    ),
                  ),
                ),
              ),

              // Policy Title
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(20, 10, 0, 0),
                child: Text(
                  AppLocalizations.of(context)!.translate('Policy') ?? 'Policy',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    letterSpacing: 0.0,
                  ),
                ),
              ),

              // Policy Text (Justified + Centered horizontally)
              Center(
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Text(
                    AppLocalizations.of(context)!.translate(
                            'At we value your privacy. We collect personal information (such as name and email) only when you provide it to us, and we use it to improve our services and communicate with you. We may use cookies to enhance your experience and track usage patterns. We do not sell or share your personal data with third parties except as required by law or to service providers who assist us in operating our website. We take reasonable steps to protect your information but cannot guarantee complete security. You have the right to access, update, or delete your personal information. By using our Service, you consent to this Privacy Policy. We may update this policy periodically, and the latest version will be posted here.') ??
                        'At we value your privacy. We collect personal information (such as name and email) only when you provide it to us, and we use it to improve our services and communicate with you. We may use cookies to enhance your experience and track usage patterns. We do not sell or share your personal data with third parties except as required by law or to service providers who assist us in operating our website. We take reasonable steps to protect your information but cannot guarantee complete security. You have the right to access, update, or delete your personal information. By using our Service, you consent to this Privacy Policy. We may update this policy periodically, and the latest version will be posted here.',
                    textAlign: TextAlign.justify,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      letterSpacing: 0.0,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
