import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:paraphrase/pdfUpload3.dart';
import 'package:paraphrase/startWithAiUrl.dart';

class StartWithAiPdfScreen extends StatefulWidget {
  const StartWithAiPdfScreen({Key? key}) : super(key: key);

  @override
  State<StartWithAiPdfScreen> createState() => _StartWithAiPdfScreenState();
}

class _StartWithAiPdfScreenState extends State<StartWithAiPdfScreen> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: const Color(0xFF101010),
        appBar: AppBar(
          backgroundColor: const Color(0xFF101010),
          automaticallyImplyLeading: false,
          leading: Padding(
            padding: const EdgeInsetsDirectional.only(start: 16),
            child: InkWell(
              splashColor: Colors.transparent,
              focusColor: Colors.transparent,
              hoverColor: Colors.transparent,
              highlightColor: Colors.transparent,
              onTap: () async {
                Navigator.of(context).pop();
              },
              child: const Icon(
                Icons.arrow_back_ios,
                color: Colors.white,
                size: 24,
              ),
            ),
          ),
          title: const Text(
            'Start with AI',
            style: TextStyle(
              color: Colors.white,
              fontSize: 22,
              letterSpacing: 0.0,
            ),
            overflow: TextOverflow.ellipsis,
          ),
          actions: const [
            Padding(
              padding: EdgeInsetsDirectional.only(end: 12),
              child: Icon(
                Icons.av_timer_rounded,
                color: Colors.white,
                size: 24,
              ),
            ),
            Padding(
              padding: EdgeInsetsDirectional.only(end: 20),
              child: FaIcon(
                FontAwesomeIcons.crown,
                color: Color(0xFFFFCC00),
                size: 24,
              ),
            ),
          ],
          centerTitle: false,
        ),
        body: SafeArea(
          top: true,
          child: SingleChildScrollView(
            child: Align(
              alignment: const AlignmentDirectional(0, 1),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsetsDirectional.fromSTEB(0, 30, 0, 20),
                    child: Container(
                      width: 352,
                      height: 69,
                      decoration: BoxDecoration(
                        color: const Color(0xFF141B1C),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          const Padding(
                            padding: EdgeInsetsDirectional.only(start: 6),
                            child: Text(
                              'Click to Add:',
                              style: TextStyle(
                                color: Color(0xFF4083D1),
                                fontSize: 17,
                                letterSpacing: 0.0,
                              ),
                            ),
                          ),
                          IconButton(
                            icon: const FaIcon(
                              FontAwesomeIcons.link,
                              color: Color(0xFF4083D1),
                              size: 24,
                            ),
                            onPressed: () async {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (_) => StartWithAiURLScreen()));
                            },
                          ),
                          const SizedBox(
                            height: 20,
                            child: VerticalDivider(
                              color: Colors.grey,
                            ),
                          ),
                          IconButton(
                            icon: const Icon(
                              Icons.attachment_rounded,
                              color: Color(0xFF4083D1),
                              size: 24,
                            ),
                            onPressed: () {
                              print('IconButton pressed ...');
                            },
                          ),
                          const SizedBox(
                            height: 20,
                            child: VerticalDivider(
                              color: Colors.grey,
                            ),
                          ),
                          IconButton(
                            icon: const Icon(
                              Icons.title,
                              color: Color(0xFF4083D1),
                              size: 24,
                            ),
                            onPressed: () async {
                              Navigator.of(context).pop();
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 361,
                        height: 238,
                        decoration: BoxDecoration(
                          color: const Color(0xFF1D252B),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: Colors.white,
                          ),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: 320,
                              height: 200,
                              decoration: BoxDecoration(
                                color: const Color(0xFF1D252B),
                                borderRadius: BorderRadius.circular(14),
                                shape: BoxShape.rectangle,
                                border: Border.all(
                                  color: const Color(0xFF4083D1),
                                ),
                              ),
                              child: Column(
                                children: [
                                  Padding(
                                    padding:
                                        const EdgeInsetsDirectional.fromSTEB(
                                            0, 20, 0, 0),
                                    child: IconButton(
                                      iconSize: 50,
                                      icon: const Icon(
                                        Icons.attachment_sharp,
                                        color: Color(0xFF4083D1),
                                        size: 50,
                                      ),
                                      onPressed: () {
                                        print('IconButton pressed ...');
                                      },
                                    ),
                                  ),
                                  const Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0, 20, 0, 0),
                                    child: Text(
                                      'Click To Upload PDF',
                                      style: TextStyle(
                                        color: Color(0xFFF1F2F2),
                                        fontSize: 20,
                                        letterSpacing: 0.0,
                                      ),
                                    ),
                                  ),
                                  const Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0, 10, 0, 0),
                                    child: Text(
                                      'Supported format: PDF',
                                      style: TextStyle(
                                        color: Color(0xFF9CA3AF),
                                        fontSize: 16,
                                        letterSpacing: 0.0,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  Padding(
                    padding:
                        const EdgeInsetsDirectional.fromSTEB(170, 30, 0, 30),
                    child: SizedBox(
                      width: 182,
                      height: 48,
                      child: ElevatedButton(
                        onPressed: () async {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => Pdf3Screen(
                                        title: 'Start with Ai',
                                        api: 'pdf',
                                      )));
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF25A6E3),
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          elevation: 0,
                        ),
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              'Next',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            SizedBox(width: 8),
                            Icon(
                              Icons.arrow_forward_ios_rounded,
                              size: 15,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
