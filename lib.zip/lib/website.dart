import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:paraphrase/website2.dart';
import 'website2_screen.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:paraphrase/app_localizations.dart';
import 'package:paraphrase/pdfUpload3.dart';
import 'package:paraphrase/subscription.dart';

class WebsiteScreen extends StatefulWidget {
  const WebsiteScreen({super.key});

  @override
  State<WebsiteScreen> createState() => _WebsiteScreenState();
}

class _WebsiteScreenState extends State<WebsiteScreen> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  final TextEditingController textController = TextEditingController();
  final FocusNode textFieldFocusNode = FocusNode();
  final FocusNode _urlFocusNode = FocusNode();
  bool _isFocused = false;

  @override
  void dispose() {
    textController.dispose();
    textFieldFocusNode.dispose();
    _urlFocusNode.dispose();
    super.dispose();
  }

  bool _isValidUrl(String url) {
    try {
      final uri = Uri.parse(url);
      return uri.hasScheme && (uri.scheme == 'http' || uri.scheme == 'https');
    } catch (e) {
      return false;
    }
  }

  String _formatUrl(String url) {
    if (url.isEmpty) return url;

    // Add https:// if no scheme is provided
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      return 'https://$url';
    }
    return url;
  }

  Future<void> _pasteFromClipboard() async {
    try {
      final clipboardData = await Clipboard.getData(Clipboard.kTextPlain);
      if (clipboardData?.text != null) {
        setState(() {
          textController.text = clipboardData!.text!;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('URL pasted successfully!'),
            backgroundColor: Color(0xFF5FF2A1),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Failed to paste from clipboard'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _onFocusChange() {
    setState(() {
      _isFocused = _urlFocusNode.hasFocus;
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: const Color(0xFF101010),
        appBar: AppBar(
          backgroundColor: const Color(0xFF101010),
          automaticallyImplyLeading: false,
          leading: IconButton(
            icon:
                const Icon(Icons.arrow_back_ios, color: Colors.white, size: 24),
            onPressed: () => Navigator.of(context).pop(),
          ),
          title: Text(
            AppLocalizations.of(context)!.translate('Website') ?? 'Website',
            style: TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.w600,
            ),
          ),
          actions: [
            const Padding(
              padding: EdgeInsets.only(right: 30),
              child: Icon(
                Icons.av_timer_rounded,
                color: Colors.white,
                size: 24,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(right: 10),
              child: IconButton(
                icon: const FaIcon(
                  FontAwesomeIcons.crown,
                  color: Color(0xFFFFCC00),
                  size: 24,
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const SubscriptionPlanScreen(),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              // Blue Banner
              Align(
                alignment: Alignment.topCenter,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(0, 30, 0, 20),
                  child: Container(
                    width: 364,
                    height: 69,
                    decoration: BoxDecoration(
                      color: const Color(0xFF1D252B),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 16),
                          child: Text(
                            AppLocalizations.of(context)!.translate(
                                    'Please share with us the URL') ??
                                'Please share with us the URL',
                            style: TextStyle(
                              color: Color(0xFF4083D1),
                              fontSize: 17,
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(right: 10),
                          child: Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: const Color(0xFF273E55),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: IconButton(
                              icon: const Icon(
                                Icons.add_circle,
                                color: Color(0xFF4083D1),
                                size: 24,
                              ),
                              onPressed: () {},
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // URL Text Field
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Container(
                  width: double.infinity,
                  height: 467,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0F1617),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: _isFocused
                          ? const Color(0xFF75EDAB)
                          : const Color(0xFF4083D1),
                      width: 2,
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: TextField(
                      controller: textController,
                      focusNode: _urlFocusNode,
                      maxLines: null,
                      expands: true,
                      textAlignVertical: TextAlignVertical.top,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                      decoration: InputDecoration(
                        hintText: AppLocalizations.of(context)!
                                .translate('Enter URL here') ??
                            'Enter URL here',
                        hintStyle: TextStyle(
                          color: Colors.white70,
                          fontSize: 16,
                        ),
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        contentPadding: EdgeInsets.zero,
                      ),
                      cursorColor: Colors.white,
                    ),
                  ),
                ),
              ),

              const Spacer(),

              // Next Button
              Padding(
                padding: const EdgeInsets.only(bottom: 30, right: 24),
                child: Align(
                  alignment: Alignment.centerRight,
                  child: SizedBox(
                    width: 182,
                    height: 48,
                    child: ElevatedButton(
                      onPressed: textController.text.trim().isNotEmpty &&
                              _isValidUrl(_formatUrl(textController.text))
                          ? () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => Website2Screen(
                                    websiteUrl: _formatUrl(textController.text),
                                  ),
                                ),
                              );
                            }
                          : null,
                      style: ElevatedButton.styleFrom(
                        backgroundColor:
                            textController.text.trim().isNotEmpty &&
                                    _isValidUrl(_formatUrl(textController.text))
                                ? const Color(0xFF25A6E3)
                                : Colors.grey,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        elevation: 0,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            AppLocalizations.of(context)!.translate('Next') ??
                                'Next',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const SizedBox(width: 8),
                          const Icon(
                            Icons.arrow_forward_ios_rounded,
                            size: 15,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
