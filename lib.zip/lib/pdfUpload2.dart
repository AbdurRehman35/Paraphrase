import 'package:flutter/material.dart';
import 'package:paraphrase/constant/color_constant.dart';
import 'package:paraphrase/pdfUpload3.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class Pdf2Screen extends StatefulWidget {
  const Pdf2Screen({super.key});

  @override
  State<Pdf2Screen> createState() => _Pdf2ScreenState();
}

class _Pdf2ScreenState extends State<Pdf2Screen> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: const Color(0xFF101010),
        appBar: AppBar(
          backgroundColor: const Color(0xFF101010),
          automaticallyImplyLeading: false,
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: const Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
              size: 24,
            ),
            padding: const EdgeInsets.only(left: 8),
          ),
          title: const Text(
            'PDF',
            style: TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.w600,
            ),
          ),
          actions: [
            const Icon(
              Icons.av_timer_rounded,
              color: Colors.white,
              size: 24,
            ),
            const SizedBox(width: 16),
            const FaIcon(
              FontAwesomeIcons.crown,
              color: Color(0xFFFFCC00),
              size: 24,
            ),
            const SizedBox(width: 16),
          ],
          centerTitle: false,
        ),
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              // Blue Banner
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 30, 16, 20),
                child: Container(
                  width: double.infinity,
                  height: 69,
                  decoration: BoxDecoration(
                    color: const Color(0xFF1D252B),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Expanded(
                          child: Text(
                            'Please Share with us the PDF file',
                            style: TextStyle(
                              color: Color(0xFF4083D1),
                              fontSize: 17,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                        IconButton(
                          onPressed: () {
                            print('Add button pressed');
                          },
                          icon: Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: const Color(0xFF273E55),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Icon(
                              Icons.add_circle,
                              color: Color(0xFF4083D1),
                              size: 24,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // PDF Document Label
              Padding(
                padding: const EdgeInsets.only(left: 20),
                child: Row(
                  children: [
                    const Text(
                      'PDF Document',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),

              // PDF File Display
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 30, 16, 0),
                child: Container(
                  width: double.infinity,
                  height: 78,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0F1617),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: Colors.white,
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(9),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // PDF Icon
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: const Color(0xFFE0DEE2),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Icon(
                            Icons.picture_as_pdf_outlined,
                            color: Color(0xFF007AFF),
                            size: 24,
                          ),
                        ),

                        // File Name
                        const Expanded(
                          child: Padding(
                            padding: EdgeInsets.symmetric(horizontal: 12),
                            child: Text(
                              'BusinessMemo.pdf',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),

                        // File Size
                        const Text(
                          '22kb',
                          style: TextStyle(
                            color: Color(0xFFE0DEE2),
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                          ),
                        ),

                        const SizedBox(width: 12),

                        // Delete Button
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: const Color(0xFF0F1617),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: IconButton(
                            onPressed: () {
                              print('Delete button pressed');
                            },
                            icon: const Icon(
                              Icons.delete_outlined,
                              color: Color(0xFF23AEF0),
                              size: 24,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              const Spacer(),

              // Next Button
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 40),
                child: Align(
                  alignment: Alignment.centerRight,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      print('Next button pressed');
                      // Navigate to next screen
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => Pdf3Screen(
                                    title: 'PDF',
                                    api: '',
                                  )));
                    },
                    icon: const Icon(
                      Icons.arrow_forward_ios_rounded,
                      size: 15,
                      color: Colors.white,
                    ),
                    label: const Text(
                      'Next',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: ColorConstant.primaryColor,
                      minimumSize: const Size(182, 48),
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      elevation: 0,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
