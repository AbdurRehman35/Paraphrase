import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:paraphrase/subscription.dart';

class Pdf3Screen extends StatefulWidget {
  final String title;
  final String api;
  String? text;
  File? file;
  Pdf3Screen(
      {super.key,
      required this.title,
      required this.api,
      this.text,
      this.file});

  @override
  State<Pdf3Screen> createState() => _Pdf3ScreenState();
}

class _Pdf3ScreenState extends State<Pdf3Screen> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  String selectedAction = 'Summarize';
  String selectedLanguage = 'English';
  int selectedLengthIndex = 2; // Medium selected by default
  String selectedTone = 'General';

  final List<String> lengthOptions = [
    'X-Small',
    'Small',
    'Medium',
    'Large',
    'X-Large'
  ];
  final List<Map<String, dynamic>> toneOptions = [
    {'name': 'General', 'isPremium': false},
    {'name': 'Academic', 'isPremium': true},
    {'name': 'Funny', 'isPremium': false},
    {'name': 'Businesslike', 'isPremium': true},
    {'name': 'Work', 'isPremium': false},
    {'name': 'Analytical', 'isPremium': true},
    {'name': 'Inspirational', 'isPremium': true},
    {'name': 'Gossip', 'isPremium': false},
    {'name': 'Journalistic', 'isPremium': false},
    {'name': 'Playful', 'isPremium': false},
    {'name': 'Creative', 'isPremium': false},
    {'name': 'Persuasive', 'isPremium': false},
    {'name': 'Neutral', 'isPremium': false},
    {'name': 'Professional', 'isPremium': false},
    {'name': 'Sarcastic', 'isPremium': false},
    {'name': 'Concise', 'isPremium': false},
    {'name': 'Critical', 'isPremium': false},
    {'name': 'Formal', 'isPremium': false},
    {'name': 'Dating', 'isPremium': false},
    {'name': 'Balanced', 'isPremium': false},
    {'name': 'Storytelling', 'isPremium': false},
    {'name': 'Witty', 'isPremium': false},
  ];

  Future<void> uploadPDF() async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return const AlertDialog(
          backgroundColor: Color(0xFF1D252B),
          content: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF25A6E3)),
              ),
              SizedBox(width: 20),
              Text(
                'Processing...',
                style: TextStyle(color: Colors.white),
              ),
            ],
          ),
        );
      },
    );
    try {
      var uri = Uri.parse(
          'https://buildwish.nexltech.com/public/api/paraphrase/${widget.api}');

      var request = http.MultipartRequest('POST', uri);

      // Add tone as a text field
      request.fields['tone'] = selectedTone.toLowerCase();

      // Add the actual PDF file
      if (widget.title == 'Photo/Camera') {
        request.files.add(
          await http.MultipartFile.fromPath(
            'image', // 👈 This must match the backend's expected field name
            widget.file!.path,
            // contentType: MediaType('application', 'pdf'),
          ),
        );
      } else if (widget.title == 'PDF') {
        request.files.add(
          await http.MultipartFile.fromPath(
            'pdf', // 👈 This must match the backend's expected field name
            widget.file!.path,
            // contentType: MediaType('application', 'pdf'),
          ),
        );
      } else if (widget.title == 'Audio File') {
        log(widget.file!.path);
        request.files.add(
          await http.MultipartFile.fromPath(
            'audio', // 👈 This must match the backend's expected field name
            widget.file!.path,
            // contentType: MediaType('application', 'pdf'),
          ),
        );
      }

      // Send the request
      var response = await request.send();

      Navigator.of(context).pop();
      log(response.statusCode.toString());

      if (response.statusCode == 200) {
        String responseBody = await response.stream.bytesToString();

        // Try to parse JSON response
        String displayText;
        try {
          Map<String, dynamic> responseData = json.decode(responseBody);

          // Extract paraphrased_output from the nested data structure
          if (responseData['data'] != null &&
              responseData['data']['paraphrased_output'] != null) {
            displayText = responseData['data']['paraphrased_output'];
            // Also get the actual tone used by the API
            log(displayText.toString());
          } else {
            // Fallback if structure is different
            displayText = responseData['paraphrased_output'] ??
                responseData['result'] ??
                responseBody;
          }
        } catch (e) {
          displayText = responseBody;
          log(displayText);
        }
        // Show success dialog with response
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              backgroundColor: const Color(0xFF1D252B),
              title: const Text(
                'Result',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
              content: Container(
                width: double.maxFinite,
                constraints: const BoxConstraints(maxHeight: 400),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Flexible(
                      child: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            // const Text(
                            //   'Original file:',
                            //   style: TextStyle(
                            //     color: Color(0xFF25A6E3),
                            //     fontWeight: FontWeight.bold,
                            //     fontSize: 14,
                            //   ),
                            // ),
                            // const SizedBox(height: 8),
                            // Container(
                            //   width: double.infinity,
                            //   padding: const EdgeInsets.all(12),
                            //   decoration: BoxDecoration(
                            //     color: const Color(0xFF0F1617),
                            //     borderRadius: BorderRadius.circular(8),
                            //     border: Border.all(
                            //       color: const Color(0xFF4083D1),
                            //       width: 1,
                            //     ),
                            //   ),
                            //   child: Text(
                            //     widget.text!,
                            //     style: const TextStyle(
                            //       color: Colors.white70,
                            //       fontSize: 14,
                            //     ),
                            //   ),
                            // ),
                            const SizedBox(height: 16),
                            Row(
                              children: [
                                const Text(
                                  'Result (',
                                  style: TextStyle(
                                    color: Color(0xFF5FF2A1),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                  ),
                                ),
                                Text(
                                  selectedTone,
                                  style: const TextStyle(
                                    color: Color(0xFFFFCC00),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                  ),
                                ),
                                const Text(
                                  ' tone):',
                                  style: TextStyle(
                                    color: Color(0xFF5FF2A1),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: const Color(0xFF0F1617),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color: const Color(0xFF5FF2A1),
                                  width: 1,
                                ),
                              ),
                              child: Text(
                                displayText,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                // TextButton(
                //   onPressed: () {
                //     // Copy result to clipboard
                //     Clipboard.setData(ClipboardData(text: displayText));
                //     ScaffoldMessenger.of(context).showSnackBar(
                //       const SnackBar(
                //         content: Text('Result copied to clipboard!'),
                //         backgroundColor: Color(0xFF5FF2A1),
                //         duration: Duration(seconds: 2),
                //       ),
                //     );
                //   },
                //   child: const Text(
                //     'Copy Result',
                //     style: TextStyle(color: Color(0xFF25A6E3)),
                //   ),
                // ),
                TextButton(
                  onPressed: () {
                    // Copy original text to clipboard
                    Clipboard.setData(ClipboardData(text: widget.text!));
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Original text copied to clipboard!'),
                        backgroundColor: Color(0xFF4083D1),
                        duration: Duration(seconds: 2),
                      ),
                    );
                  },
                  child: const Text(
                    'Copy Original',
                    style: TextStyle(color: Color(0xFF4083D1)),
                  ),
                ),
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text(
                    'Close',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            );
          },
        );
      } else {
        // Show error dialog
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              backgroundColor: const Color(0xFF1D252B),
              title: const Row(
                children: [
                  Icon(
                    Icons.error_outline,
                    color: Colors.red,
                    size: 24,
                  ),
                  SizedBox(width: 8),
                  Text(
                    'Error',
                    style: TextStyle(
                      color: Colors.red,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Status Code: ${response.statusCode}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Error: ${response.reasonPhrase ?? 'Unknown error occurred'}',
                    style: const TextStyle(color: Colors.white70),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text(
                    'OK',
                    style: TextStyle(color: Color(0xFF25A6E3)),
                  ),
                ),
              ],
            );
          },
        );
      }
    } catch (e) {
      // Close loading dialog if still open
      Navigator.of(context).pop();

      // Show network error dialog
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: const Color(0xFF1D252B),
            title: const Row(
              children: [
                Icon(
                  Icons.wifi_off,
                  color: Colors.orange,
                  size: 24,
                ),
                SizedBox(width: 8),
                Text(
                  'Network Error',
                  style: TextStyle(
                    color: Colors.orange,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Failed to connect to server.',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Error: $e',
                  style: const TextStyle(color: Colors.white70),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text(
                  'OK',
                  style: TextStyle(color: Color(0xFF25A6E3)),
                ),
              ),
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  apiCall(); // Retry the API call
                },
                child: const Text(
                  'Retry',
                  style: TextStyle(color: Color(0xFF5FF2A1)),
                ),
              ),
            ],
          );
        },
      );
    }
  }

  Future<void> apiCall() async {
    // Show loading dialog
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return const AlertDialog(
          backgroundColor: Color(0xFF1D252B),
          content: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF25A6E3)),
              ),
              SizedBox(width: 20),
              Text(
                'Processing...',
                style: TextStyle(color: Colors.white),
              ),
            ],
          ),
        );
      },
    );

    try {
      var headers = {'Content-Type': 'application/json'};
      var request = http.Request(
          'POST',
          Uri.parse(
              'https://buildwish.nexltech.com/public/api/paraphrase/${widget.api}'));
      if (widget.title == "Text or Email") {
        request.body = json
            .encode({"text": widget.text, "tone": selectedTone.toLowerCase()});
      } else if (widget.title == "PDF") {
        log(widget.file!.path.toString());
        request.body = json.encode(
            {"pdf": widget.file!.path, "tone": selectedTone.toLowerCase()});
      } else if (widget.title == "Website" || widget.title == "YouTube") {
        log(widget.text.toString());
        request.body = json
            .encode({"url": widget.text, "tone": selectedTone.toLowerCase()});
      }

      request.headers.addAll(headers);

      http.StreamedResponse response = await request.send();

      // Close loading dialog
      Navigator.of(context).pop();

      if (response.statusCode == 200) {
        String responseBody = await response.stream.bytesToString();

        // Try to parse JSON response
        String displayText;
        try {
          Map<String, dynamic> responseData = json.decode(responseBody);

          // Extract paraphrased_output from the nested data structure
          if (responseData['data'] != null &&
              responseData['data']['paraphrased_output'] != null) {
            displayText = responseData['data']['paraphrased_output'];
            // Also get the actual tone used by the API
          } else {
            // Fallback if structure is different
            displayText = responseData['paraphrased_output'] ??
                responseData['result'] ??
                responseBody;
          }
        } catch (e) {
          displayText = responseBody;
          log(displayText);
        }
        // Show success dialog with response
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              backgroundColor: const Color(0xFF1D252B),
              title: const Text(
                'Result',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
              content: Container(
                width: double.maxFinite,
                constraints: const BoxConstraints(maxHeight: 400),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Flexible(
                      child: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Text(
                              'Original Text:',
                              style: TextStyle(
                                color: Color(0xFF25A6E3),
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: const Color(0xFF0F1617),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color: const Color(0xFF4083D1),
                                  width: 1,
                                ),
                              ),
                              child: Text(
                                widget.text!,
                                style: const TextStyle(
                                  color: Colors.white70,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                            const SizedBox(height: 16),
                            Row(
                              children: [
                                const Text(
                                  'Result (',
                                  style: TextStyle(
                                    color: Color(0xFF5FF2A1),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                  ),
                                ),
                                Text(
                                  selectedTone,
                                  style: const TextStyle(
                                    color: Color(0xFFFFCC00),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                  ),
                                ),
                                const Text(
                                  ' tone):',
                                  style: TextStyle(
                                    color: Color(0xFF5FF2A1),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: const Color(0xFF0F1617),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color: const Color(0xFF5FF2A1),
                                  width: 1,
                                ),
                              ),
                              child: Text(
                                displayText,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    // Copy result to clipboard
                    Clipboard.setData(ClipboardData(text: displayText));
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Result copied to clipboard!'),
                        backgroundColor: Color(0xFF5FF2A1),
                        duration: Duration(seconds: 2),
                      ),
                    );
                  },
                  child: const Text(
                    'Copy Result',
                    style: TextStyle(color: Color(0xFF25A6E3)),
                  ),
                ),
                TextButton(
                  onPressed: () {
                    // Copy original text to clipboard
                    Clipboard.setData(ClipboardData(text: widget.text!));
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Original text copied to clipboard!'),
                        backgroundColor: Color(0xFF4083D1),
                        duration: Duration(seconds: 2),
                      ),
                    );
                  },
                  child: const Text(
                    'Copy Original',
                    style: TextStyle(color: Color(0xFF4083D1)),
                  ),
                ),
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text(
                    'Close',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            );
          },
        );
      } else {
        // Show error dialog
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              backgroundColor: const Color(0xFF1D252B),
              title: const Row(
                children: [
                  Icon(
                    Icons.error_outline,
                    color: Colors.red,
                    size: 24,
                  ),
                  SizedBox(width: 8),
                  Text(
                    'Error',
                    style: TextStyle(
                      color: Colors.red,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Status Code: ${response.statusCode}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Error: ${response.reasonPhrase ?? 'Unknown error occurred'}',
                    style: const TextStyle(color: Colors.white70),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text(
                    'OK',
                    style: TextStyle(color: Color(0xFF25A6E3)),
                  ),
                ),
              ],
            );
          },
        );
      }
    } catch (e) {
      // Close loading dialog if still open
      Navigator.of(context).pop();

      // Show network error dialog
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: const Color(0xFF1D252B),
            title: const Row(
              children: [
                Icon(
                  Icons.wifi_off,
                  color: Colors.orange,
                  size: 24,
                ),
                SizedBox(width: 8),
                Text(
                  'Network Error',
                  style: TextStyle(
                    color: Colors.orange,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Failed to connect to server.',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Error: $e',
                  style: const TextStyle(color: Colors.white70),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text(
                  'OK',
                  style: TextStyle(color: Color(0xFF25A6E3)),
                ),
              ),
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  apiCall(); // Retry the API call
                },
                child: const Text(
                  'Retry',
                  style: TextStyle(color: Color(0xFF5FF2A1)),
                ),
              ),
            ],
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: const Color(0xFF101010),
        appBar: AppBar(
          backgroundColor: const Color(0xFF101010),
          automaticallyImplyLeading: false,
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: const Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
              size: 24,
            ),
            padding: const EdgeInsets.only(left: 8),
          ),
          title: Text(
            widget.title,
            style: TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.w600,
            ),
          ),
          actions: [
            const Icon(
              Icons.av_timer_rounded,
              color: Colors.white,
              size: 24,
            ),
            const SizedBox(width: 16),
            IconButton(
              icon: const FaIcon(
                FontAwesomeIcons.crown,
                color: Color(0xFFFFCC00),
                size: 24,
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const SubscriptionPlanScreen(),
                  ),
                );
              },
            ),
            const SizedBox(width: 16),
          ],
          centerTitle: false,
        ),
        body: SafeArea(
          top: true,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                // Select Action Title
                Padding(
                  padding: const EdgeInsets.only(top: 25),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        'Select Action',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),

                // Action Buttons
                Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildActionButton('Summarize'),
                      _buildActionButton('Paraphrase'),
                    ],
                  ),
                ),

                // Output Languages
                Padding(
                  padding: const EdgeInsets.only(top: 25, left: 25),
                  child: Row(
                    children: [
                      const Text(
                        'Output Languages',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),

                // Language Selector
                Padding(
                  padding: const EdgeInsets.fromLTRB(25, 25, 25, 0),
                  child: Container(
                    width: double.infinity,
                    height: 57,
                    decoration: BoxDecoration(
                      color: const Color(0xFF0F4864),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: const Color(0xFFE0DEE2)),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: selectedLanguage,
                        dropdownColor: const Color(0xFF0F4864),
                        icon: const Icon(Icons.arrow_drop_down,
                            color: Colors.white),
                        style:
                            const TextStyle(color: Colors.white, fontSize: 16),
                        items: [
                          'English',
                          'Spanish',
                          'French',
                          'German',
                          'Italian'
                        ].map((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Padding(
                              padding: const EdgeInsets.only(left: 16),
                              child: Text(value),
                            ),
                          );
                        }).toList(),
                        onChanged: (String? newValue) {
                          setState(() {
                            selectedLanguage = newValue!;
                          });
                        },
                      ),
                    ),
                  ),
                ),

                // Length Section
                Padding(
                  padding: const EdgeInsets.only(top: 25, left: 25),
                  child: Row(
                    children: [
                      const Text(
                        'Length:',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),

                // Length Options
                Padding(
                  padding: const EdgeInsets.only(top: 27),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: lengthOptions.asMap().entries.map((entry) {
                      int index = entry.key;
                      String length = entry.value;
                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            selectedLengthIndex = index;
                          });
                        },
                        child: Text(
                          length,
                          style: TextStyle(
                            color: selectedLengthIndex == index
                                ? const Color(0xFF25A6E3)
                                : const Color(0xFFE0DEE2),
                            fontSize: 14,
                            fontWeight: selectedLengthIndex == index
                                ? FontWeight.w600
                                : FontWeight.w400,
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),

                // Tone Section
                Padding(
                  padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
                  child: Row(
                    children: [
                      const Padding(
                        padding: EdgeInsets.only(left: 20),
                        child: Text(
                          'Tone',
                          style: TextStyle(
                            color: Color(0xFFF7F9F6),
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      const Spacer(),
                      Padding(
                        padding: const EdgeInsets.only(right: 0),
                        child: GestureDetector(
                          onTap: () {
                            // Existing onTap if any, otherwise leave empty or add a placeholder
                          },
                          child: Container(
                            height: 40,
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            decoration: BoxDecoration(
                              color: const Color(0xFF212121),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: Colors.white24),
                            ),
                            alignment: Alignment.center,
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                if (toneOptions.firstWhere((element) =>
                                    element['name'] ==
                                    selectedTone)['isPremium'])
                                  const Padding(
                                    padding: EdgeInsets.only(right: 5),
                                    child: FaIcon(
                                      FontAwesomeIcons.crown,
                                      color: Color(0xFFFFC100),
                                      size: 16,
                                    ),
                                  ),
                                Text(
                                  selectedTone,
                                  style: const TextStyle(
                                    color: Color(0xFFF7F9F6),
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 20),
                        child: TextButton(
                          onPressed: () => _showToneSelectionDialog(context),
                          child: const Text(
                            'View All',
                            style: TextStyle(
                              color: Color(0xFF23AEF0),
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // Tone Chips - First Row
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildToneChip('General', false),
                      _buildToneChip('Academic', true),
                      _buildToneChip('Funny', false),
                      _buildToneChip('Businesslike', true),
                    ],
                  ),
                ),

                // Tone Chips - Second Row
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildToneChip('Work', false),
                      _buildToneChip('Analytical', true),
                      _buildToneChip('Inspirational', true),
                      _buildToneChip('Gossip', false),
                    ],
                  ),
                ),

                // Bottom Buttons
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 60, 16, 40),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      // Back Button
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          icon: const Icon(
                            Icons.chevron_left,
                            size: 30,
                            color: Colors.white,
                          ),
                          label: const Text(
                            'Back',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF0F4864),
                            minimumSize: const Size(0, 50),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            elevation: 0,
                          ),
                        ),
                      ),

                      const SizedBox(width: 16),

                      // Finish Button
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () {
                            if (widget.title == 'PDF' ||
                                widget.title == 'Photo/Camera' ||
                                widget.title == 'Audio File') {
                              uploadPDF();
                            } else {
                              apiCall();
                            }
                          },
                          icon: const Icon(
                            Icons.newspaper_outlined,
                            size: 30,
                            color: Colors.white,
                          ),
                          label: const Text(
                            'Finish',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF25A6E3),
                            minimumSize: const Size(0, 50),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            elevation: 0,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildActionButton(String action) {
    bool isSelected = selectedAction == action;
    return ElevatedButton(
      onPressed: () {
        setState(() {
          selectedAction = action;
        });
      },
      style: ElevatedButton.styleFrom(
        backgroundColor:
            isSelected ? const Color(0xFF23AEF0) : const Color(0xFF0F4864),
        minimumSize: const Size(140, 36),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(22),
        ),
        elevation: 0,
      ),
      child: Text(
        action,
        style: TextStyle(
          color: isSelected ? Colors.white : const Color(0xFFEBE8EE),
          fontSize: 12,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildToneChip(String tone, bool isPremium) {
    bool isSelected = selectedTone == tone;
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedTone = tone;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF23AEF0) : const Color(0xFF0F4864),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (isPremium) ...[
              const Icon(
                Icons.star,
                color: Color(0xFFEBE8EE),
                size: 17,
              ),
              const SizedBox(width: 5),
            ],
            Text(
              tone,
              style: TextStyle(
                color: const Color(0xFFEBE8EE),
                fontSize: 12,
                fontWeight: isPremium ? FontWeight.normal : FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showProcessingModal() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF101010),
      isScrollControlled: true,
      enableDrag: false,
      builder: (context) {
        return Container(
          height: 700,
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const CircularProgressIndicator(
                color: Color(0xFF25A6E3),
              ),
              const SizedBox(height: 20),
              const Text(
                'Processing ..',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'Action: $selectedAction\nLanguage: $selectedLanguage\nLength: ${lengthOptions[selectedLengthIndex]}\nTone: $selectedTone',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Color(0xFFE0DEE2),
                  fontSize: 14,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _showToneSelectionDialog(BuildContext context) async {
    String? tempSelectedTone =
        selectedTone; // Use a temporary variable for dialog's state

    final newTone = await showDialog<String>(
      context: context,
      builder: (BuildContext dialogContext) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return AlertDialog(
              backgroundColor: const Color(0xFF1D252B),
              title: const Text(
                'Tones Frame',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
                textAlign: TextAlign.center,
              ),
              content: SizedBox(
                width: double.maxFinite,
                child: SingleChildScrollView(
                  child: Wrap(
                    spacing: 8.0, // horizontal space
                    runSpacing: 8.0, // vertical space
                    children: toneOptions.map((tone) {
                      final toneName = tone['name'] as String;
                      final isPremium = tone['isPremium'] as bool;
                      final isSelected = tempSelectedTone == toneName;

                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            tempSelectedTone = toneName;
                          });
                          Navigator.of(dialogContext)
                              .pop(toneName); // Pop the selected tone
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 10),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? const Color(0xFF23AEF0)
                                : const Color(0xFF212121),
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(
                              color: isSelected
                                  ? const Color(0xFF23AEF0)
                                  : const Color(0xFF424242),
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (isPremium)
                                const Padding(
                                  padding: EdgeInsets.only(right: 5),
                                  child: FaIcon(
                                    FontAwesomeIcons.crown,
                                    color: Color(0xFFFFC100),
                                    size: 16,
                                  ),
                                ),
                              Text(
                                toneName,
                                style: TextStyle(
                                  color: isSelected
                                      ? Colors.white
                                      : const Color(0xFFF7F9F6),
                                  fontSize: 16,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(dialogContext)
                        .pop(); // Close without selecting
                  },
                  child: const Text('Cancel',
                      style: TextStyle(color: Color(0xFF23AEF0))),
                ),
              ],
            );
          },
        );
      },
    );

    if (newTone != null) {
      setState(() {
        selectedTone = newTone;
      });
    }
  }
}
