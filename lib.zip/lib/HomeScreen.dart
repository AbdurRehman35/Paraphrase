import 'package:flutter/material.dart';
import 'package:paraphrase/app_localizations.dart';
import 'package:paraphrase/audioFile.dart';
import 'package:paraphrase/history.dart';
import 'package:paraphrase/pdfUpload.dart';
import 'package:paraphrase/photoCamera.dart';
import 'package:paraphrase/startWithAi.dart';
import 'package:paraphrase/subscription.dart';
import 'package:paraphrase/textEmail.dart';
import 'package:paraphrase/website.dart';
import 'package:paraphrase/youtube.dart';
import 'setting.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    if (_selectedIndex != index) {
      setState(() {
        _selectedIndex = index;
      });

      // Navigate to other screens if not Home
      switch (index) {
        case 1:
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => StartWithAIScreen()),
          );
          break;
        case 2:
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => HistoryScreen()),
          );
          break;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(18, 18, 18, 1),
      body: SafeArea(
        child: Column(
          children: [
            _buildAppBar(context),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildAIAssistantCard(context),
                    const SizedBox(height: 24),
                    Text(
                      AppLocalizations.of(context)!.translate('Create Using') ??
                          'Create Using',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Expanded(child: _buildOptionsGrid(context)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _buildDynamicBottomNavBar(),
    );
  }

  Widget _buildAppBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          GestureDetector(
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => SettingsScreen()));
            },
            child: const Icon(Icons.settings, color: Colors.white, size: 28),
          ),
          Row(
            children: [
              GestureDetector(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => HistoryScreen()));
                },
                child: const Icon(Icons.history, color: Colors.white, size: 28),
              ),
              const SizedBox(width: 12),
              GestureDetector(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => SubscriptionPlanScreen()));
                },
                child: const FaIcon(FontAwesomeIcons.crown,
                    color: Color(0xFFFFCC00), size: 28),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAIAssistantCard(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 270,
      decoration: BoxDecoration(
        color: const Color(0xFF0F4864),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Stack(
        children: [
          Row(
            children: [
              Expanded(
                flex: 2,
                child: Padding(
                  padding: const EdgeInsets.all(18.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        AppLocalizations.of(context)!.translate(
                                'AI-Powered Reading & Writing Assistant') ??
                            'AI Powered\nParaphrasing &\nSummarizing\nAssistant',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          height: 1.2,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        AppLocalizations.of(context)!.translate(
                                'For any of your reading or\nwriting needs.') ??
                            'For any of your reading or\nwriting needs.',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => StartWithAIScreen(),
                            ),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          foregroundColor: Colors.black,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 24, vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(25),
                          ),
                        ),
                        child: Text(AppLocalizations.of(context)!
                                .translate('Start With AI') ??
                            'Start With AI'),
                      ),
                    ],
                  ),
                ),
              ),
              const Spacer(flex: 1),
            ],
          ),
          Positioned(
            bottom: 0,
            right: 0,
            child: Image.asset(
              'assets/images/mic.png',
              height: 210,
              fit: BoxFit.contain,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOptionsGrid(BuildContext context) {
    final options = [
      {
        'icon': Icons.picture_as_pdf,
        'title': AppLocalizations.of(context)!.translate('PDF Upload') ??
            'PDF\nDocument',
        'onTap': () {
          Navigator.push(
              context, MaterialPageRoute(builder: (_) => PdfUploadScreen()));
        }
      },
      {
        'icon': Icons.language,
        'title': AppLocalizations.of(context)!.translate('Website\nLinks') ??
            'Website\nLinks',
        'onTap': () {
          Navigator.push(
              context, MaterialPageRoute(builder: (_) => WebsiteScreen()));
        }
      },
      {
        'icon': Icons.play_circle_outline,
        'title': AppLocalizations.of(context)!.translate('YouTube\nVideo') ??
            'YouTube\nVideo',
        'onTap': () {
          Navigator.push(
              context, MaterialPageRoute(builder: (_) => YouTubeScreen()));
        }
      },
      {
        'icon': Icons.email_outlined,
        'title': AppLocalizations.of(context)!.translate('Text or\nEmail') ??
            'Text or\nEmail',
        'onTap': () {
          Navigator.push(
              context, MaterialPageRoute(builder: (_) => TextEmailScreen()));
        }
      },
      {
        'icon': Icons.camera_alt_outlined,
        'title': AppLocalizations.of(context)!.translate('Photo /\nCamera') ??
            'Photo /\nCamera',
        'onTap': () {
          Navigator.push(
              context, MaterialPageRoute(builder: (_) => PhotoCameraScreen()));
        }
      },
      {
        'icon': Icons.audiotrack,
        'title': AppLocalizations.of(context)!.translate('Audio File') ??
            'Audio File',
        'onTap': () {
          Navigator.push(
              context, MaterialPageRoute(builder: (_) => AudioFileScreen()));
        }
      },
    ];

    return GridView.builder(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 0.85,
      ),
      itemCount: options.length,
      itemBuilder: (context, index) {
        final option = options[index];
        return GestureDetector(
          onTap: option['onTap'] as VoidCallback,
          child: Container(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF0F4864), Color(0xFF25A6E3)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(option['icon'] as IconData,
                      color: Colors.white, size: 40),
                  const SizedBox(height: 12),
                  Text(
                    option['title'] as String,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildDynamicBottomNavBar() {
    return Container(
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF0F4864),
        borderRadius: BorderRadius.circular(25),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _buildNavItem(Icons.home, 'Home', 0),
            _buildNavItem(Icons.auto_awesome, 'AI Creation', 1),
            _buildNavItem(Icons.history, 'History', 2),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem(IconData icon, String label, int index) {
    final isSelected = _selectedIndex == index;
    return GestureDetector(
      onTap: () => _onItemTapped(index),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon,
              color: isSelected ? Colors.white : Colors.white70, size: 28),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: isSelected ? Colors.white : Colors.white70,
              fontSize: 12,
              fontWeight: isSelected ? FontWeight.w500 : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }
}
