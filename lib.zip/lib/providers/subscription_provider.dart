import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SubscriptionProvider extends ChangeNotifier {
  bool _isSubscribed = false;
  DateTime? _expiryDate;
  bool _isLoading = false;

  bool get isSubscribed => _isSubscribed;
  DateTime? get expiryDate => _expiryDate;
  bool get isLoading => _isLoading;

  Future<void> initialize() async {
    _isLoading = true;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      _isSubscribed = prefs.getBool('subscription_status') ?? false;

      final expiryString = prefs.getString('subscription_expiry');
      if (expiryString != null) {
        _expiryDate = DateTime.parse(expiryString);

        // Check if subscription has expired
        if (_expiryDate!.isBefore(DateTime.now())) {
          _isSubscribed = false;
          await prefs.setBool('subscription_status', false);
        }
      }

      print('Subscription status: $_isSubscribed');
    } catch (e) {
      print('Error initializing subscription provider: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> setSubscriptionStatus(bool status, {DateTime? expiry}) async {
    _isSubscribed = status;
    _expiryDate = expiry;

    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('subscription_status', status);

    if (expiry != null) {
      await prefs.setString('subscription_expiry', expiry.toIso8601String());
    }

    print('Subscription status updated: $status');
    notifyListeners();
  }

  bool isSubscriptionValid() {
    if (!_isSubscribed) return false;
    if (_expiryDate == null) return false;
    return _expiryDate!.isAfter(DateTime.now());
  }
}
