import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:paraphrase/pdfUpload3.dart';
import 'package:paraphrase/startWithAi.dart';
import 'package:paraphrase/startWithAiPDF.dart';

class StartWithAiURLScreen extends StatefulWidget {
  const StartWithAiURLScreen({Key? key}) : super(key: key);

  @override
  State<StartWithAiURLScreen> createState() => _StartWithAiURLScreenState();
}

class _StartWithAiURLScreenState extends State<StartWithAiURLScreen> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  late TextEditingController textController;
  late FocusNode textFieldFocusNode;

  @override
  void initState() {
    super.initState();
    textController = TextEditingController();
    textFieldFocusNode = FocusNode();
  }

  @override
  void dispose() {
    textController.dispose();
    textFieldFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: const Color(0xFF101010),
        appBar: AppBar(
          backgroundColor: const Color(0xFF101010),
          automaticallyImplyLeading: false,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
          title: const Text(
            'Start with AI',
            style: TextStyle(
              color: Colors.white,
              fontSize: 22,
              letterSpacing: 0.0,
            ),
          ),
          centerTitle: true,
          actions: const [
            Padding(
              padding: EdgeInsets.only(right: 16),
              child: Row(
                children: [
                  Icon(Icons.av_timer_rounded, color: Colors.white),
                  SizedBox(width: 12),
                  FaIcon(FontAwesomeIcons.crown, color: Color(0xFFFFCC00)),
                ],
              ),
            ),
          ],
        ),
        body: SafeArea(
          top: true,
          child: Align(
            alignment: const AlignmentDirectional(0, 1),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                const SizedBox(height: 30),
                Container(
                  width: 352,
                  height: 69,
                  decoration: BoxDecoration(
                    color: const Color(0xFF141B1C),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      const Text(
                        'Click to Add:',
                        style: TextStyle(
                          color: Color(0xFF4083D1),
                          fontSize: 17,
                          letterSpacing: 0.0,
                        ),
                      ),
                      IconButton(
                        icon: const FaIcon(
                          FontAwesomeIcons.link,
                          color: Color(0xFF4083D1),
                        ),
                        onPressed: () {},
                      ),
                      const SizedBox(
                        height: 20,
                        child: VerticalDivider(color: Colors.grey),
                      ),
                      IconButton(
                        icon: const Icon(
                          Icons.attachment_rounded,
                          color: Color(0xFF4083D1),
                        ),
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => StartWithAiPdfScreen()));
                        },
                      ),
                      const SizedBox(
                        height: 20,
                        child: VerticalDivider(color: Colors.grey),
                      ),
                      IconButton(
                        icon: const Icon(
                          Icons.title,
                          color: Color(0xFF4083D1),
                        ),
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => StartWithAIScreen()));
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'URL',
                        style: TextStyle(
                          color: Color(0xFFE0DEE2),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        '0/1500',
                        style: TextStyle(
                          color: Color(0xFFE0DEE2),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
                  child: TextFormField(
                    controller: textController,
                    focusNode: textFieldFocusNode,
                    maxLines: 2,
                    decoration: InputDecoration(
                      hintText: 'Type URL Here',
                      hintStyle: const TextStyle(
                        color: Color(0xFFE0DEE2),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(color: Color(0xFFE0DEE2)),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      filled: true,
                      fillColor: const Color(0xFF1D252B),
                    ),
                    style: const TextStyle(color: Color(0xFFE0DEE2)),
                    cursorColor: Colors.white,
                  ),
                ),
                const Spacer(),
                Padding(
                  padding: const EdgeInsets.only(bottom: 30),
                  child: SizedBox(
                    width: 182,
                    height: 48,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => Pdf3Screen(
                                      title: 'Start with Ai',
                                      api: 'website',
                                    )));
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF25A6E3),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'Next',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          SizedBox(width: 8),
                          Icon(
                            Icons.arrow_forward_ios_rounded,
                            size: 15,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
