import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:paraphrase/app_localizations.dart';
import 'package:paraphrase/pdfUpload3.dart';
import 'package:paraphrase/startWithAiPDF.dart';
import 'package:paraphrase/startWithAiUrl.dart';

class StartWithAIScreen extends StatefulWidget {
  const StartWithAIScreen({Key? key}) : super(key: key);

  @override
  State<StartWithAIScreen> createState() => _StartWithAIScreenState();
}

class _StartWithAIScreenState extends State<StartWithAIScreen> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  final TextEditingController _textController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: const Color(0xFF101010),
        appBar: AppBar(
          backgroundColor: const Color(0xFF101010),
          automaticallyImplyLeading: false,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () => Navigator.of(context).pop(),
          ),
          title: Text(
            AppLocalizations.of(context)!.translate('Start with AI') ??
                'Start with AI',
            style: TextStyle(
              color: Colors.white,
              fontSize: 22,
              letterSpacing: 0.0,
            ),
          ),
          centerTitle: true,
          actions: const [
            Padding(
              padding: EdgeInsets.only(right: 16),
              child: Row(
                children: [
                  Icon(Icons.av_timer_rounded, color: Colors.white, size: 24),
                  SizedBox(width: 12),
                  FaIcon(FontAwesomeIcons.crown,
                      color: Color(0xFFFFCC00), size: 24),
                ],
              ),
            ),
          ],
        ),
        body: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 20),
              Center(
                child: Container(
                  width: 362,
                  height: 466.8,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0F1617),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFF75EDAB)),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      const SizedBox(height: 20),
                      Container(
                        width: 352,
                        height: 69,
                        decoration: BoxDecoration(
                          color: const Color(0xFF1D252B),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Padding(
                              padding: EdgeInsets.only(left: 10),
                              child: Text(
                                AppLocalizations.of(context)!
                                        .translate('Click to Add:') ??
                                    'Click to Add:',
                                style: TextStyle(
                                  color: Color(0xFF4083D1),
                                  fontSize: 17,
                                ),
                              ),
                            ),
                            IconButton(
                              icon: const FaIcon(
                                FontAwesomeIcons.link,
                                color: Color(0xFF4083D1),
                              ),
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (_) =>
                                            StartWithAiURLScreen()));
                              },
                            ),
                            IconButton(
                              icon: const Icon(
                                Icons.attachment_sharp,
                                color: Color(0xFF4083D1),
                              ),
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (_) =>
                                            StartWithAiPdfScreen()));
                              },
                            ),
                            IconButton(
                              icon: const Icon(
                                Icons.title,
                                color: Color(0xFF4083D1),
                              ),
                              onPressed: () {},
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                      const Padding(
                        padding: EdgeInsets.only(left: 20),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          // child: Text(
                          //   'Enter your text Here',
                          //   style: TextStyle(
                          //     color: Colors.white,
                          //     fontSize: 16,
                          //   ),
                          // ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 10),
                        child: TextField(
                          controller: _textController,
                          maxLines: 5,
                          style: const TextStyle(color: Colors.white),
                          decoration: InputDecoration(
                            hintText: AppLocalizations.of(context)!
                                    .translate('Type your text here...') ??
                                'Type your text here...',
                            hintStyle: const TextStyle(color: Colors.white54),
                            filled: true,
                            fillColor: const Color(0xFF1D252B),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide:
                                  const BorderSide(color: Color(0xFF4083D1)),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide:
                                  const BorderSide(color: Color(0xFF75EDAB)),
                            ),
                          ),
                        ),
                      ),
                      const Spacer(),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 20, right: 120),
                        child: ElevatedButton.icon(
                          onPressed: () {
                            // You can access text with _textController.text
                          },
                          icon: const Icon(
                            Icons.content_paste_outlined,
                            size: 30,
                            color: Color(0xFF5FF2A1),
                          ),
                          label: Text(
                            AppLocalizations.of(context)!
                                    .translate('Paste now') ??
                                'Paste now',
                            style: TextStyle(color: Color(0xFF5FF2A1)),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF132E38),
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            minimumSize: const Size(0, 40),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 30),
              SizedBox(
                width: 182,
                height: 48,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => Pdf3Screen(
                          title: AppLocalizations.of(context)!
                                  .translate('Start with Ai') ??
                              'Start with Ai',
                          api: 'text',
                          text: _textController.text,
                        ),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF25A6E3),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    elevation: 0,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        AppLocalizations.of(context)!.translate('Next') ??
                            'Next',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(width: 8),
                      Icon(
                        Icons.arrow_forward_ios_rounded,
                        size: 15,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
